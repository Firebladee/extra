================
Sphinx internals
================

This guide contains information about the Sphinx open source project itself.
This is where you can find information about how Sphinx is managed and learn
how to contribute to the project.

.. toctree::
   :maxdepth: 2

   contributing
   release-process
   organization
   code-of-conduct
   authors
