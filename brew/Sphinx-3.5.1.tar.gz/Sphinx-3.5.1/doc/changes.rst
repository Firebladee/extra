:tocdepth: 1

.. default-role:: any

.. _changes:

=========
Changelog
=========

.. raw:: latex

   \hypersetup{bookmarksdepth=1}% pdf bookmarks
   \addtocontents{toc}{\protect\setcounter{tocdepth}{1}}%

.. include:: ../CHANGES
