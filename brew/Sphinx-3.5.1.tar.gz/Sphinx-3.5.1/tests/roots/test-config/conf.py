project = 'Sphinx <Tests>'
release = '0.6alpha1'
templates_path = ['_templates']
