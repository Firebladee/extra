﻿File with UTF-8 BOM
===================

This file has a UTF-8 "BOM".

