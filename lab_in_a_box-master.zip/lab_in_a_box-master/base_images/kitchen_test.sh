#!/bin/bash

# shellcheck disable=SC2034
name=vagrant

loop="centos6_backup_master,centos/6"

#driver_name=$name loop=$loop erb .kitchen.yml
#loop=$loop erb .kitchen.yml
loop=$loop kitchen list
