#!/bin/bash

# shellcheck disable=SC2034
nexus_ip=127.0.0.1
nexus_docker_group_port=8125

os_images="centos6-backup-master,centos,6"

#driver_name=$name loop=$loop erb .kitchen.yml
os_images=$os_images nexus_ip=$nexus_ip nexus_docker_group_port=$nexus_docker_group_port erb -T - concourse.yaml 
#loop=$loop kitchen list
