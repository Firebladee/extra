# frozen_string_literal: true

all

exclude_rule 'MD013'
exclude_rule 'MD033'
exclude_rule 'MD041'
