#!/bin/bash

# shellcheck disable=SC2046,SC1083
nexus_ip=$(kubectl get pod $(kubectl get pod -l "app=sonatype-nexus" -o jsonpath="{.items[0].metadata.name}") --template={{.status.podIP}})
nexus_docker_group_port=8125
nexus_port=8081

if [ -n "$1" ];
then
  fly -t local set-pipeline -n -p lab-in-a-box -c concourse.yaml --var "nexus_ip=$nexus_ip" --var "nexus_docker_group_port=$nexus_docker_group_port" --var "nexus_port=$nexus_port" --var "branch=$1" -l ../private_git
else
  fly -t local set-pipeline -n -p lab-in-a-box -c concourse.yaml --var "nexus_ip=$nexus_ip" --var "nexus_docker_group_port=$nexus_docker_group_port" --var "nexus_port=$nexus_port" --var "branch=master" -l ../private_git
fi
fly -t local unpause-pipeline -p lab-in-a-box
