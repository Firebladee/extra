[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/pre-commit/pre-commit)

# Lab_In_A_Box

For main documentation please look under the folder Docs.

## Quick test use

For quick use then then default config.yaml file will work but you will need a few things installed and configured.

* local kubernetes.  i.e. minikube
* helm
* default concourse installed by helm
* default nexus installed by helm
  * Create repositories
    * hosted docker - port 8123
    * proxy docker - port 8124
    * group docker - port 8125
    * yum proxy - called yum
* in a seperate cmd windows 'kubectl port-forward \<concourse-web pod name> 8080:8080

```bash
cd main
./lab_in_a_box -i
```

Once this has finished running there will be a kitche.yml file.  At the moment you will need to un-rem a line before doing a kitchen create command.  ( This will be fixed later ).
The line that needs un-remming is in the diver section:

```bash
driver:
  name: docker
  #build_options: --network=host
```

Change this to:

```bash
driver:
  name: docker
  build_options: --network=host
```

You may need to add ```run_options: --network=host```
