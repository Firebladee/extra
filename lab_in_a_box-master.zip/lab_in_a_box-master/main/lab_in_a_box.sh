#!/bin/bash
set -e
#set -u
set -o pipefail

# This will be the main script to build the lab in a box.
# This would only need to be run the once to build the lab in a box
# on your local machine.

# Assumusions

# Kubernetes is running and docker is also installed.
# Access to the banks github and nexus systems.
# Maybe access to the proxy?

# inputs

# nothing/start/build
#   This will build everything that is needed.
#   e.g. Nexus, Jenkins

# Fix
#   This will take a git branch with the stored results of the build and
#   attempt to fix the lab in a box system on your local machine.

# Rebuild
#   This will destroy and rebuild the lab in a box from fresh.

# Destroy
#   This will destroy the lab in a box on you local machine.

help() {
  printf " -b  --de-bug         Show debug messages.\n"
  printf " -c  --config_file    Select the config file.  Default is config.yaml.\n"
  printf " -d  --destroy        This will destroy.  Can use -c option.\n"
  printf " -f  --fix            This will atemp to fix.  Can use -c option.\n"
  printf " -h  --help           This help screen.\n"
  printf " -i  --install        This will install into you kubernetes cluster.\n" 
  printf " -r  --rebuild        This will rebuild.  Can use -c option.\n"
}

# Set variables defaults
# Need to update these with any config.yaml changes
variables() {
  printf "Getting variables from %s " "$config_file"

  if [[ -z $(yq r "$config_file" name) ]]
  then
    pipeline_name=lab-in-a-box
  else
    pipeline_name=$(yq r "$config_file" name)
  fi
  if [[ $debug ]]
  then
    echo "pipeline_name = $pipeline_name"
  fi
  printf "."

  if [[ -z $(yq r "$config_file" working_folder) ]]
  then
    working_folder=.lab_in_a_box
  else
    working_folder=$(yq r "$config_file" working_folder)
  fi
  if [[ $debug ]]
  then
    echo "working_folder = $working_folder"
  fi
  printf "."

  if [[ -z $(yq r "$config_file" pipeline ) || $(yq r "$config_file" pipeline.type ) = concourse ]]
  then
    pipeline=concourse
  else
    pipeline=$(yq r "$config_file" pipeline.type )
  fi
  if [[ $debug ]]
  then
    echo "pipeline = $pipeline"
  fi
  printf "."

  if [[ $pipeline = "concourse" ]]
  then
    # shellcheck disable=SC2034
    concourse_dns=concourse-web.default.svc.cluster.local
    if [[ $debug ]]
    then
      echo "concourse_dns = $concourse_dns"
    fi
    printf "."

    if [[ -z $(yq r "$config_file" pipeline.type.concourse_target ) ]]
    then
      concourse_target=local
    else
      concourse_target=$(yq r "$config_file" pipeline.type.concourse_target )
    fi
    if [[ $debug ]]
    then
      echo "concourse_target = $concourse_target"
    fi
    printf "."
  fi

  if [[ -z $(yq r "$config_file" pipeline.build ) ]]
  then
    pipeline_build=true
  else
    pipeline_build=$(yq r "$config_file" pipeline.build )
  fi
  if [[ $debug ]]
  then
    echo "pipeline_build = $pipeline_build"
  fi
  printf "."

  if [[ -z $(yq r "$config_file" storage ) || $(yq r "$config_file" storage.type ) = nexus ]]
  then
    storage=nexus
  else
    storage=$(yq r "$config_file" storage.type )
  fi
  if [[ $debug ]]
  then
    echo "storage = $storage"
  fi
  printf "."

  if [[ $storage = "nexus" ]]
  then
    if [[ -z $(yq r "$config_file" storage.type.nexus_ip ) || $(yq r "$config_file" storage.local ) = true ]]
    then
      # shellcheck disable=SC2046,SC1083
      nexus_ip=$(kubectl get pod $(kubectl get pod -l "app=sonatype-nexus" -o jsonpath="{.items[0].metadata.name}") --template={{.status.podIP}})
    else
      nexus_ip=$(yq r "$config_file" storage.type.nexus_ip )
    fi
    if [[ $debug ]]
    then
      echo "nexus_ip = $nexus_ip"
    fi
    printf "."

    if [[ -z $(yq r "$config_file" storage.type.nexus_docker_group_port ) ]]
    then
      nexus_docker_group_port=8125
    else
      nexus_docker_group_port=$(yq r "$config_file" storage.type.nexus_docker_group_port )
    fi
    if [[ $debug ]]
    then
      echo "nexus_docker_group_port = $nexus_docker_group_port"
    fi
    printf "."

    if [[ -z $(yq r "$config_file" storage.type.nexus_docker_port ) ]]
    then
      nexus_docker_port=8123
    else
      nexus_docker_port=$(yq r "$config_file" storage.type.nexus_docker_port )
    fi
    if [[ $debug ]]
    then
      echo "nexus_docker_port = $nexus_docker_port"
    fi
    printf "."

    if [[ -z $(yq r "$config_file" storage.type.nexus_port ) ]]
    then
      nexus_port=8081
    else
      nexus_port=$(yq r "$config_file" storage.type.nexus_port )
    fi
    if [[ $debug ]]
    then
      echo "nexus_port = $nexus_port"
    fi
    printf "."

    if [[ -z $(yq r "$config_file" storage.type.username ) ]]
    then
      nexus_username="admin"
    else
      nexus_username=$(yq r "$config_file" storage.type.username )
    fi
    if [[ $debug ]]
    then
      echo "nexus_username = $nexus_username"
    fi
    printf "."

    if [[ -z $(yq r "$config_file" storage.type.password ) ]]
    then
      nexus_password=admin123
    else
      nexus_password=$(yq r "$config_file" storage.type.password )
    fi
    # No debug message for password as this is bound to later on be stored somewhere else
    printf "."  
  fi

  if [[ -z $(yq r "$config_file" storage.build ) ]]
  then
    storage_build=true
  else
    storage_build=$(yq r "$config_file" storage.build)
  fi
  if [[ $debug ]]
  then
    echo "storage_build = $storage_build"
  fi
  printf "."

  if [[ -z $(yq r "$config_file" code.private ) ]]
  then
    code_private=false
  else
    code_private=$(yq r "$config_file" code.private)
    code_private_key_file=$(yq r "$config_file" code.private_key_file)
  fi
  if [[ $debug ]]
  then
    echo "code_private = $code_private"
    echo "code_private_key_file = $code_private_key_file"
  fi
  printf ".\n"
}

check() {
  debug=$1

   if ! command -v docker &> /dev/null
  then
    echo "Sorry but we need docker to be installed and running"
    exit
  fi

  if ! command -v yq &> /dev/null
  then
    yq() {
      docker run --rm -i -v "${PWD}":/workdir mikefarah/yq yq "$@"
    }
  fi

  if ! command -v fly &> /dev/null
  then
    docker_fly=true
    fly() {
      cp ../../../private_git .
      docker run --net="host" --rm -i -v "${PWD}":/workdir fireblade/fly "$@" 2> /dev/null
      rm private_git
    }
  fi

  if ! command -v erb &> /dev/null
  then
    docker_erb=true
  fi

  if ! command -v helm &> /dev/null
  then
    helm() {
      docker run -ti --rm -v "$(pwd)":/apps -v ~/.kube:/root/.kube -v ~/.helm:/root/.helm alpine/helm
    }
  fi
}

kitchen_base_docker() {
  printf "Building test kitchen base config "

  # Build platform arrary
  for ((loop_base = 0; loop_base <= $(yq r "$config_file" -l base) -1; ++loop_base )); do
    temp_name=$(yq r "$config_file" -p p "base[$loop_base].*" | awk -F'.' '{print $NF}')
    for ((loop_os = 0; loop_os <= $(yq r "$config_file" -l os) -1; ++loop_os )); do
      os_name=$(yq r "$config_file" -p p "os[$loop_os].*" | awk -F'.' '{print $NF}')
      for ((loop_version = 0; loop_version <= $(yq r "$config_file" -l os[$loop_os]."$os_name".versions) - 1; ++loop_version )); do
        version=$(yq r "$config_file" -p p "os[$loop_os].$os_name.versions[$loop_version].*" | awk -F'"' '{print $(NF-1)}')
        if [[ $(yq r "$config_file" os[$loop_os]."$os_name".versions[$loop_version]."$version".update) != false ]]
        then
          base_platforms="$base_platforms ${temp_name}_${os_name}_${version},${nexus_ip}:${nexus_docker_port}/${os_name}_update:$version,$os_name"
        elif [[ $(yq r "$config_file" os[$loop_os]."$os_name".versions[$loop_version]."$version".convert) != false ]]
        then
          base_platforms="$base_platforms ${temp_name}_${os_name}_${version},${nexus_ip}:${nexus_docker_port}/${os_name}_convert:$version,$os_name"
        else
          base_platforms="$base_platforms ${temp_name}_${os_name}_${version},${nexus_ip}:${nexus_docker_port}/$os_name:$version,$os_name"
        fi
        printf "."
      done
    done
  done
  printf "\n"
  base_platforms=${base_platforms#"${base_platforms%%[! ]*}"} base_platforms=${base_platforms%"${base_platforms##*[! ]}"}
  kitchen_base=true

  if [[ $debug ]]
  then
    platforms=$base_platforms erb kitchen.yml
    platforms=$base_platforms erb kitchen.yml > base_kitchen.yml
  fi
}

kitchen_base() {
  cp ../../base_images/kitchen.yml .

  case $(yq r "$config_file" kitchen_base) in
    docker)
      kitchen_base_docker
      ;;
    vagrant)
      kitchen_base_vagrant
      ;;
    *)
      kitchen_base_docker
      ;;
  esac
}

nexus_build() {
  debug=$1
  # This still needs lots of work so not yet available
  echo "Install Nexus"
  #minikube addons enable ingress
  #helm repo add oteemocharts https://oteemo.github.io/charts
  #helm install nexus oteemocharts/sonatype-nexus
}

storage() {
  debug=$1
  if [[ $debug ]]
  then
    echo "Image Storage"
  fi
  if $storage_build ;
  then
    echo "Building nexus"
    # nexus_build
  fi
}

concourse_nexus() {
  debug=$1

  printf "Building pipeline %s " "${pipeline_name}"
  cp ../../combine/concourse.yaml concourse.yaml

  for ((loop_os = 0; loop_os <= $(yq r "$config_file" -l os) -1; ++loop_os )); do
    os_name=$(yq r "$config_file" -p p "os[$loop_os].*" | awk -F'.' '{print $NF}')

    if [[ $debug ]]
    then
      echo "os_name = $os_name"
    fi

    for ((loop_version = 0; loop_version <= $(yq r "$config_file" -l os[$loop_os]."$os_name".versions) -1; ++loop_version ));do
      version=$(yq r "$config_file" -p p "os[$loop_os].$os_name.versions[$loop_version].*" | awk -F'"' '{print $(NF-1)}')

      if [[ $debug ]]
      then
        echo "version = $version"
      fi

      uri=$(yq r "$config_file" os[$loop_os]."$os_name".versions[$loop_version]."$version".uri)

      if [[ $debug ]]
      then
        echo "uri = $uri"
      fi

      if [[ $(yq r "$config_file" os[$loop_os]."$os_name".versions[$loop_version]."$version".trigger) != false ]]
      then
        trigger=true
      else
        trigger=
      fi
      if [[ $debug ]]
      then
        echo "trigger = $trigger"
      fi

      if [[ $(yq r "$config_file" os[$loop_os]."$os_name".versions[$loop_version]."$version".update) != false ]]
      then
        update=true
      else
        update=
      fi
      if [[ $debug ]]
      then
        echo "update = $update"
      fi

      if [[ $(yq r "$config_file" os[$loop_os]."$os_name".versions[$loop_version]."$version".convert) != false ]]
      then
        external_url="$external_url ${os_name},${version},${uri}"
        convert="$convert ${os_name},${version},${trigger}"
        convert_option=true
      else
        convert_option=
      fi

      if [[ $debug ]]
      then
        echo "external_url = $external_url"
        echo "convert = $convert"
      fi

      if [[ $(yq r "$config_file" os[$loop_os]."$os_name".versions[$loop_version]."$version".update) != false ]]
      then
        update_images="$update_images ${os_name},${version},${update},${convert_option}"

        if [[ $debug ]]
        then
          echo "update_images = $update_images"
        fi
      fi

      if [[ $update ]]
      then
        location="update"
      elif [[ $convert ]]
      then
        location="convert"
      else
        location=
      fi

      base="$base ${os_name},${version},${location}"

      if [[ $debug ]]
      then
        echo "base = $base"
      fi
      printf "."

    done
  done

  printf "\n"

  external_url=${external_url#"${external_url%%[! ]*}"} external_url=${external_url%"${external_url##*[! ]}"}
  convert=${convert#"${convert%%[! ]*}"} convert=${convert%"${convert##*[! ]}"}
  update_images=${update_images#"${update_images%%[! ]*}"} update_images=${update_images%"${update_images##*[! ]}"}
  base=${base#"${base%%[! ]*}"} base=${base%"${base##*[! ]}"}
  source_url=$(yq r "$config_file" code.url)
  source_private=$code_private

  kitchen_base

  if [[ $debug ]]
  then
    echo "Final external_url = $external_url"
    echo "Final convert = $convert"
    echo "update_images = $update_images"
    echo "base = $base"
    echo "kitchen base = $base_platforms"
    echo "source_url = $source_url"
    echo "source_private = $source_private"
    if [[ $docker_erb ]]
    then
      docker run --rm -i -e external_url="$external_url" -e convert="$convert" -e update_images="$update_images" -e kitchen_base="$kitchen_base" -e base="$base" -e source_url="$source_url" -e source_private="$source_private" -v "${PWD}":/usr/src/lab -w /usr/src/lab library/ruby erb -T - concourse.yaml
      echo "Docker run"
      docker run --rm -i -e platforms="$base_platforms" -v "${PWD}":/usr/src/lab -w /usr/src/lab library/ruby erb -T - kitchen.yml
    else
      external_url=$external_url convert=$convert update_images=$update_images kitchen_base=$kitchen_base base=$base source_url=$source_url source_private=$source_private erb -T - concourse.yaml
      platforms=$base_platforms erb kitchen.yml
    fi
  fi

  if [[ $docker_erb ]]
  then
    docker run --rm -i -e external_url="$external_url" -e convert="$convert" -e update_images="$update_images" -e kitchen_base="$kitchen_base" -e base="$base" -e source_url="$source_url" -e source_private="$source_private" -v "${PWD}":/usr/src/lab -w /usr/src/lab library/ruby erb -T - concourse.yaml > "$pipeline_name"_concourse.yaml
  else
    external_url=$external_url convert=$convert update_images=$update_images kitchen_base=$kitchen_base base=$base source_url=$source_url source_private=$source_private erb -T - concourse.yaml > "$pipeline_name"_concourse.yaml
  fi

  {
    echo "nexus_ip: $nexus_ip"
    echo "nexus_docker_group_port: \"$nexus_docker_group_port\""
    echo "nexus_docker_port: \"$nexus_docker_port\""
    echo "base_platforms: $base_platforms"
    echo "nexus_username: $nexus_username"
    echo "nexus_password: $nexus_password"
    echo "nexus_port: \"$nexus_port\""
  } > variables_"$pipeline_name".yaml



  if [[ $docker_fly ]]
  then
    if [[ $code_private ]]
    then
      fly set-pipeline "$pipeline_name" "$pipeline_name"_concourse.yaml variables_"$pipeline_name".yaml private_git
    else
      fly set-pipeline "$pipeline_name" "$pipeline_name"_concourse.yaml variables_"$pipeline_name".yaml
    fi
    fly unpause-pipeline "$pipeline_name"
  else
    if [[ $code_private ]]
    then
      fly -t "$concourse_target" set-pipeline -n -p "$pipeline_name" -c "$pipeline_name"_concourse.yaml -l variables_"$pipeline_name".yaml -l ../../../private_git
    else
      fly -t "$concourse_target" set-pipeline -n -p "$pipeline_name" -c "$pipeline_name"_concourse.yaml -l variables_"$pipeline_name".yaml
    fi
    fly -t local unpause-pipeline -p "$pipeline_name"
  fi
}

concourse() {
  debug=$1

  if [[ $debug ]]
  then
    echo "function = concourse; storage = $storage"
  fi

  case $storage in
    nexus)
      concourse_nexus "$debug"
      ;;
    *)
      echo "$storage" "not supported"
      exit
      ;;
  esac
}

jenkins() {
  echo "not yet implemented"
}

install() {
  debug=$1

  check "$debug"

  if [[ -z $2 ]]
  then
    config_file=config.yaml
  else
    config_file=$2
  fi

  # Validate config file
  printf "Validating config file %s" "$config_file"
  yq v "$config_file" || printf "failed"
  printf "  Passed\n\n"

  variables "$debug"

  # create working folder
  if [[ -n $(yq r "$config_file" working_folder) ]];
  then
    working_folder=$(yq r "$config_file" working_folder)
  fi

  [ ! -d "$working_folder" ] && mkdir "$working_folder"

  cp "$config_file" "$working_folder"

  # Main loop

  # shellcheck disable=SC1066,SC1068,SC1097
  if [[ $storage_build ]]
  then
    storage "$debug"
  fi

  pushd "$working_folder" > /dev/null

  case $pipeline in
    concourse)
      concourse "$debug"
      ;;
    jenkins)
      jenkins "$debug"
    ;;
    *)
      concourse "$debug"
      ;;
  esac

  popd > /dev/null
}

final_kitchen() {
  debug=$1
  echo "final_kitchen"

  pushd "$working_folder" > /dev/null

  for ((loop_base = 0; loop_base <= $(yq r "$config_file" -l base) -1; ++loop_base )); do
    temp_name=$(yq r "$config_file" -p p "base[$loop_base].*" | awk -F'.' '{print $NF}')
    for ((loop_os = 0; loop_os <= $(yq r "$config_file" -l os) -1; ++loop_os )); do
      os_name=$(yq r "$config_file" -p p "os[$loop_os].*" | awk -F'.' '{print $NF}')
      for ((loop_version = 0; loop_version <= $(yq r "$config_file" -l os[$loop_os]."$os_name".versions) - 1; ++loop_version )); do
        version=$(yq r "$config_file" -p p "os[$loop_os].$os_name.versions[$loop_version].*" | awk -F'"' '{print $(NF-1)}')
        # shellcheck disable=SC2034
        #box_name=$(yq r $config_file base[$loop_base].*.uri)
        final_platforms="$final_platforms ${temp_name}_${os_name}_${version},127.0.0.1:${nexus_docker_group_port}/${temp_name}_${os_name}_${version},$os_name"
        printf "."
      done
    done
  done
  printf "\n"
  final_platforms=${final_platforms#"${final_platforms%%[! ]*}"} final_platforms=${final_platforms%"${final_platforms##*[! ]}"}

  final_platforms=${final_platforms//_/-}
  #echo "final platforms = $final_platforms"

  #platforms=$final_platforms erb kitchen.yml

  popd > /dev/null

  platforms=$final_platforms erb "$working_folder"/kitchen.yml > kitchen.yml
}

final_vagrant() {
  echo "final_vagrant"

  pushd "$working_folder" > /dev/null
  cp ../../vagrant/final/Vagrantfile .

  for ((loop_base = 0; loop_base <= $(yq r "$config_file" -l base) -1; ++loop_base )); do
    temp_name=$(yq r "$config_file" -p p "base[$loop_base].*" | awk -F'.' '{print $NF}')
    for ((loop_os = 0; loop_os <= $(yq r "$config_file" -l os) -1; ++loop_os )); do
      os_name=$(yq r "$config_file" -p p "os[$loop_os].*" | awk -F'.' '{print $NF}')
      for ((loop_version = 0; loop_version <= $(yq r "$config_file" -l os[$loop_os]."$os_name".versions) - 1; ++loop_version )); do
        version=$(yq r "$config_file" -p p "os[$loop_os].$os_name.versions[$loop_version].*" | awk -F'"' '{print $(NF-1)}')
        final_platforms="$final_platforms 127.0.0.1:${nexus_docker_group_port}/${temp_name}_${os_name}_${version},${temp_name}_${os_name}_${version}"
        printf "."
      done
    done
  done
  printf "\n"
  final_platforms=${final_platforms#"${final_platforms%%[! ]*}"} final_platforms=${final_platforms%"${final_platforms##*[! ]}"}

  final_platforms=${final_platforms//_/-}
  #echo "final platforms = $final_platforms"

  #nodes=$final_platforms erb -T - Vagrantfile

  popd > /dev/null

  nodes=$final_platforms erb -T - "$working_folder"/Vagrantfile > Vagrantfile
}

final() {
  debug=$1
  echo "Create final config"

  if [[ -z $(yq r "$config_file" final_config) ]];
  then
    if [[ $debug ]]
    then
      echo "blank final_config"
    fi
    final_kitchen "$debug" 
  elif [[ -z $(yq r "$config_file" final_config.type) ]];
  then
    if [[ $debug ]]
    then
      echo "bank final_config.type"
    fi
    final_kitchen "$debug"
  elif [[ $(yq r "$config_file" final_config.type) == kitchen ]];
  then
    if [[ $debug ]]
    then
      echo "final_config.type = kitchen"
    fi
    final_kitchen "$debug"
  elif [[ $(yq r "$config_file" final_config.type) == vagrant ]];
  then
    if [[ $debug ]]
    then
      echo "final_config.type = vagrant"
    fi
    final_vagrant "$debug"
  else
    echo "Sorry but $(yq r "$config_file" final_config.type) is not valid"
    exit
  fi
}

fix() {
  debug=$1
  echo "Not yet implemented"
}

rebuild() {
  debug=$1
  echo "Not yet implemented"
}

destroy() {
  debug=$1
  echo "Not yet implemented"
}

while [[ "$1" =~ ^- && ! "$1" == "--" ]]; do case $1 in
  -b | --de-bug )
    debug=true
    ;;
  -c | --config_file )
    shift; config_file=$1
    ;;
  -h | --help )
    help
    exit
    ;;
  -f | --fix )
    fix $debug
    exit
    ;;
  -r | --rebuild )
    rebuild $debug
    exit
    ;;
  -d | --destroy )
    destroy $debug
    exit
    ;;
  -i | --install )
    install $debug "$config_file"
    final $debug
    exit
    ;;
esac; shift; done
if [[ "$1" == '--' ]]; then shift; fi

help
