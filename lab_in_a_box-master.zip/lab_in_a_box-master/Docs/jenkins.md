# Jenkins

## How to install

### Get repo info

```bash
helm repo add jenkins https://charts.jenkins.io
helm repo update
```

### Install chart

```bash
helm install jenkins jenkins/jenkins
```

## Access web site

First we need to get the login password:

```bash
kubectl exec --namespace default -it svc/jenkins -c jenkins -- /bin/cat /run/secrets/chart-admin-password && echo
```

Then next we need to set up the port-forward so we can access the web site:

```bash
kubectl port-forward svc/jenkins 8082:8080
```

Then in a web browser access <http://127.0.0.1:8082>

## API Commands

### Build

```bash
curl -X POST --user <username>:<password> http://127.0.0.1:8082/job/<name of build>/build
```

### Get job xml

```bash
curl -X GET -u admin:1155f13bdfd251842d185aa9a20bae30d6 http://127.0.0.1:8082/job/convert/config.xml -o jenkins.xml
```
