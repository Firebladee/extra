# Nexus

## Installing

This is simple to install so do the following:

```bash
helm repo add oteemocharts https://oteemo.github.io/charts
helm install nexus oteemocharts/sonatype-nexus
```

Once installed then to access the web site do:

```bash
export POD_NAME=$(kubectl get pods -l "app=sonatype-nexus" -o jsonpath="{.items[0].metadata.name}")
kubectl port-forward $POD_NAME 8081:8081
```

Then in a web browser go to <http://127.0.01:8081>
Default username is **admin**.  Default passwd is **admin123**

## Setup Repositories

### Docker Repositiories

We now need to set up some Docker repositories.  For this we need to set up three repositories.

* hosted docker with port 8123
* proxy docker with port 8124

For both of these only use <http://> and select 'Allow anonymous docker pull' and select 'Enable Docker V1 API:'
For the proxy docker also use <https://registry-1.docker.io> for 'remote storage:', select 'Use the Nexus truststore:' and select 'Foreign Layer Caching:'.

Next create

* group docker with port 8125

Again with only <http://> and select 'Allow anonymous docker pull:' and select 'Enable Docker V1 API:'.  Add both the above repoistories into this group.

Once last thing to do and that is to add 'DockerBearer Token Realm' in the Realms config.

### Yum Repositiories

This is a simple yum proxy repository with the name yum.  Use the i.e. for the 'Remote Storage', <http://mirror.centos.org/centos/>
