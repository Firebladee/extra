# Installing Concourse

This is nice and simple:

```bash
helm repo add concourse https://concourse-charts.storage.googleapis.com/
helm install concourse concourse/concourse
```

Once installed then to access the web site do:

```bash
export POD_NAME=$(kubectl get pods --namespace default -l "app=concourse-web" -o jsonpath="{.items[0].metadata.name}")
kubectl port-forward $POD_NAME 8080:8080
```

Then in a web browser go to <http://127.0.0.1:8080>
Default username and password is **test**
