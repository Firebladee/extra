# Config details for yaml file

The following table lists the configurable parametes of the lab_in_a_box config file and there default values.<br/>
An example of this config is in the main folder of the repo.<br/>
This is subject to change.

Parameter | Description | Default
--- | --- | ---
name | The name of the project |
os | A list of the OS's that are in this project |
os.name.versions | The list of versions for the os |
os.name.versions.uri | The uri of where to get the image |
os.name.versions.update | Update pipeline is used | true
os.name.versions.convert | The convert pipeline is used | true
convert.from | Which way to convert the images | vm
convert.to | Which way to convert the images | docker
base | A list of the base images to be created |
base.type | The configuration system to use for building |
base.uri | The uri of where to get the building code |
base.config | The location of where to get the config |
pipeline.type | The app to use for the pipelines | concourse
pipeline.local | Location of where the pipelines will be built | true
pipeline.build | Will lab_in_a_box build the pipeline app | false
image_storage.type | The app to use for storage of the images and for local caching | nexus
image_storage.local | Where the storage is located | true
image_storage.build | Will we build the storage system | false
extra | Details of extra pipelines | <pre>pipeline:<br/>  yum_update:<br/>    uri:<br/>    after: convert<br/>    before: base_build</pre>
testing | A list of the testing to be done.  Includes building the base images |
testing.name | name of the test group | base<br/>final
testing.name.when | After what pipeline does this run | during base build<br/>last
testing.name.pipeline | Does this need a pipeline | true
testing.name.kitchen | What system to use.  Vagrant to come later | test kitchen
testing.name.kitchen.type | what system to use to build service | docker
testing.name.kitchen.uri | Location of the code |
