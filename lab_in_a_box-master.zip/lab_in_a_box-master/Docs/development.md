# How to Develope Lab_in_a_Box

## What you need to start development work for lab_in_a_box

### Software that needs to be installed

* kubernetes
* helm
* pre-commit
* fly
* docker

### Software that needs to be installed in kubernetes

* nexus
* concourse
* jenkins

## First steps

Once you have git cloned lab_in_a_box then the first then you need to do is run

```bash
pre-commit install
```

This will setup the git pre-commits so every time you do a ```git commit``` command these pre-commit will run and validate a lot of the files in this project.
Your next step is to get the concourse testing pipeline up and running.  To do this then run:

```bash
./local_nexus.sh
```

Buy default this pipeline will be setup running agenst the master branch.  For the first run it is best to run agaenst the master branch.  To change it over to your working branch then run:

```bash
./local_nexus.sh <branch_name>
```
